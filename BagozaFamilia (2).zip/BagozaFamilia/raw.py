import re, os, sys, time, json, urllib, string, random
import socket, struct, quopri, base64, colored, smtplib
import datetime, requests, binascii, pyperclip
from datetime import date
from datetime import datetime
from colored import fg, bg, attr
from time import gmtime, strftime
from uuid import getnode as get_mac
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from multiprocessing.pool import ThreadPool
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
mac = get_mac()

USER_SETTINGS_	   = "C:\\BagozaFamilia\\SETTINGS.txt"
USER_SERIAL_	  	 = "C:\\BagozaFamilia\\LICENSE.txt"
Ask_For_Letters	  = "C:\\BagozaFamilia\\LETTERS.txt"
Ask_For_Sender_Names = "C:\\BagozaFamilia\\NAMES.txt"
Ask_For_Subjects	 = "C:\\BagozaFamilia\\SUBJECTS.txt"
Ask_For_MailList	 = "C:\\BagozaFamilia\\MAILIST.txt"
Ask_For_SMTPS		= "C:\\BagozaFamilia\\SMTPS.txt"
Ask_For_URLs		 = "C:\\BagozaFamilia\\URLS.txt"
Ask_For_Mailers	  = "C:\\BagozaFamilia\\MAILERS.txt"
HEADERS_FILE_		= "C:\\BagozaFamilia\\HEADERS.txt"
CUTTLY_APIs_FILE_	= "C:\\BagozaFamilia\\CUTT.txt"
MAILERS_FILE		 = "C:\\BagozaFamilia\\MAILERS.txt"

#SERIAL_	   = open(USER_SERIAL_, "r").read()
#R__ = requests.get("https://bagozasndr.com/v3.exe/serials.php?action=info&serial={}&mac={}".format(SERIAL_, mac), verify=False).content
#if "error=" not in R__ and "Name" in R__ and "Mac" in R__:
#	Name = R__.split("Name: ")[1].split(" - ")[0]
#else:
#	print "FUCK U BITCH, GO PLAY AWAY!!!!"
#	time.sleep(50000)

MAILERS_FILE  = open(MAILERS_FILE, "r").read()

ADMIN_PATH = os.environ['USERPROFILE']
DESKTOP_PATH = ADMIN_PATH + '\Desktop'

def Random_IP():
	IP = socket.inet_ntoa(struct.pack('>I', random.randint(1, 0xffffffff)))
	return IP
def Random_OS():
	OSs = ['Windows', 'Linux', 'IOS', 'Android', 'MacOS']
	OS = random.choice(OSs)
	return OS
def Current_Date():
	today = date.today()
	DATE = today.strftime("%B %d, %Y")
	return DATE
def Random_Country():
	Countries = ['France', 'Spain', 'United States', 'China', 'Argentina', 'Peru', 'Canada', 'Brazil', 'United Kingdom', 'Germany', 'Thailand', 'Mexico', 'Turkey', 'Italy', 'Isreal']
	Country = random.choice(Countries)
	return Country
def Random_Email():
	Names = ['support', 'admin', 'lead', 'manager', 'administrator']
	TLDs = ['@supporting.com', '@helping.com', '@assisting.com', '@teaming.com']
	RAND_EMAIL = random.choice(Names)+random.choice(TLDs)
	return RAND_EMAIL
def Random_Browser():
	Countries = ['Chrome', 'Firefox', 'Edge', 'Safari', 'Opera', 'QQ', 'Yandex', 'UC Browser', 'Maxthon', 'Chromium', 'AOSP']
	Browser = random.choice(Countries)
	return Browser
def Random_Name():
	Names_List = ["Aaron", "Abbey", "Abbie", "Abby", "Abdul", "Abe" ,"Bonny", "Booker", "Boris", "Boyce", "Boyd", "Brad", "Bradford", "Caitlin", "Caitlyn", "Calandra", "Caleb", "Calista", "Callie", "Calvin", "Donette", "Dong", "Dong", "Donita", "Donn", "Donna", "Donnell", "Earl", "Earle", "Earlean", "Earleen", "Earlene", "Earlie", "Earline", "Frederick", "Fredericka", "Fredia", "Fredric", "Fredrick", "Fredricka", "Gabriel", "Gabriela", "Gabriele", "Gabriella", "Gabrielle", "Gail", "Gail", "Gala", "Gale", "Gale", "Galen", "Galina", "Garfield", "Garland", "Garnet", "Hortencia", "Hortense", "Hortensia", "Hosea", "Houston", "Howard", "Hoyt", "Hsiu", "Hubert", "Hue", "Huey", "Hugh", "Hugo", "Hui", "Hulda", "Humberto", "Hung", "Hunter", "Hyon", "Hyun", "Ian", "Ida", "Idalia", "Idell", "Idella", "Iesha", "Ignacia", "Ignacio", "Jacalyn", "Jacelyn", "Jacinda", "Jacinta", "Jacinto", "Jack", "Jack", "Jackeline", "Ka", "Kacey", "Kaci", "Kacie", "Kacy", "Kai", "Kaila", "Kaitlin", "Kaitlyn", "Kala", "Kaleigh", "Kaley", "Kali", "Lacey", "Lachelle", "Laci", "Lacie", "Lacresha", "Lacy", "Lacy", "Ladawn", "Ladonna", "Ma", "Mabel", "Mabelle", "Mable", "Mac", "Machelle", "Macie", "Mack", "Na", "Nada", "Nadene", "Nadia", "Nadine", "Naida", "Nakesha", "Nakia", "Nakisha", "Nakita", "Nam", "Nenita", "Neoma", "Neomi", "Nereida", "Nerissa", "Nery", "Nestor", "Neta", "Nettie", "Neva", "Nevada", "Neville", "Newton", "Nga", "Ngan", "Ngoc", "Nguyet", "Nia", "Nichelle", "Nichol", "Nicholas", "Nichole", "Nicholle", "Nick", "Nicki", "Nickie", "Nickolas", "Nickole", "Nicky", "Nicky", "Nicol", "Nicola", "Nicolas", "Nicolasa", "Nicole", "Nicolette", "Nicolle", "Nida", "Nidia", "Niesha", "Nieves", "Nigel", "Niki", "Nikia", "Nikita", "Nikki", "Nikole", "Nila", "Nilda", "Nilsa", "Nina", "Ninfa", "Nisha", "Nita", "Noah", "Noble", "Nobuko", "Noe", "Noel", "Noel", "Noelia", "Noella", "Noelle", "Noemi", "Nohemi", "Nola", "Nolan", "Noma", "Nona", "Nora", "Norah", "Norbert", "Norberto", "Noreen", "Norene", "Noriko", "Norine", "Norma", "Norman", "Norman", "Normand", "Norris", "Nova", "Novella", "Nu", "Nubia", "Numbers", "Numbers", "Nydia", "Nyla", "Obdulia", "Ocie", "Octavia", "Octavio", "Oda", "Odelia", "Odell", "Odell", "Odessa", "Odette", "Odilia", "Odis", "Ofelia", "Ok", "Ola", "Olen", "Olene", "Oleta", "Olevia", "Olga", "Olimpia", "Olin", "Olinda", "Oliva", "Olive", "Oliver", "Olivia", "Ollie", "Ollie", "Olympia", "Oma", "Omar", "Omega", "Omer", "Ona", "Oneida", "Onie", "Onita", "Opal", "Ophelia", "Ora", "Oralee", "Oralia", "Oren", "Oretha", "Orlando", "Orpha", "Orval", "Orville", "Oscar", "Oscar", "Ossie", "Osvaldo", "Oswaldo", "Otelia", "Otha", "Otha", "Otilia", "Otis", "Otto", "Ouida", "Owen", "Ozell", "Ozella", "Ozie", "Prince", "Princess", "Priscila", "Priscilla", "Providencia", "Prudence", "Pura", "Quincy", "Quinn", "Quinn", "Quintin", "Quinton", "Quyen", "Ruthanne", "Ruthe", "Ruthie", "Ryan", "Ryan", "Ryann", "Syble", "Sydney", "Sydney", "Sylvester", "Sylvia", "Sylvie", "Synthia", "Syreeta", "Tyra", "Tyree", "Tyrell", "Tyron", "Tyrone", "Tyson", "Ula", "Ulrike", "Ulysses", "Un", "Una", "Ursula", "Usha", "Ute", "Vada", "Val", "Val", "Vivien", "Vivienne", "Von", "Voncile", "Vonda", "Vonnie", "Wonda", "Woodrow", "Wyatt", "Wynell", "Wynona", "Yun", "Yung", "Yuonne", "Yuri", "Yuriko", "Yvette", "Yvone", "Yvonne", "Zora", "Zoraida", "Zula", "Zulema", "Zulma"]
	FIRST_NAME = random.choice(Names_List)
	return FIRST_NAME
def Random_NameX():
	Names_List = ["Aaron", "Abbey", "Abbie", "Abby", "Abdul", "Abe" ,"Bonny", "Booker", "Boris", "Boyce", "Boyd", "Brad", "Bradford", "Caitlin", "Caitlyn", "Calandra", "Caleb", "Calista", "Callie", "Calvin", "Donette", "Dong", "Dong", "Donita", "Donn", "Donna", "Donnell", "Earl", "Earle", "Earlean", "Earleen", "Earlene", "Earlie", "Earline", "Frederick", "Fredericka", "Fredia", "Fredric", "Fredrick", "Fredricka", "Gabriel", "Gabriela", "Gabriele", "Gabriella", "Gabrielle", "Gail", "Gail", "Gala", "Gale", "Gale", "Galen", "Galina", "Garfield", "Garland", "Garnet", "Hortencia", "Hortense", "Hortensia", "Hosea", "Houston", "Howard", "Hoyt", "Hsiu", "Hubert", "Hue", "Huey", "Hugh", "Hugo", "Hui", "Hulda", "Humberto", "Hung", "Hunter", "Hyon", "Hyun", "Ian", "Ida", "Idalia", "Idell", "Idella", "Iesha", "Ignacia", "Ignacio", "Jacalyn", "Jacelyn", "Jacinda", "Jacinta", "Jacinto", "Jack", "Jack", "Jackeline", "Ka", "Kacey", "Kaci", "Kacie", "Kacy", "Kai", "Kaila", "Kaitlin", "Kaitlyn", "Kala", "Kaleigh", "Kaley", "Kali", "Lacey", "Lachelle", "Laci", "Lacie", "Lacresha", "Lacy", "Lacy", "Ladawn", "Ladonna", "Ma", "Mabel", "Mabelle", "Mable", "Mac", "Machelle", "Macie", "Mack", "Na", "Nada", "Nadene", "Nadia", "Nadine", "Naida", "Nakesha", "Nakia", "Nakisha", "Nakita", "Nam", "Nenita", "Neoma", "Neomi", "Nereida", "Nerissa", "Nery", "Nestor", "Neta", "Nettie", "Neva", "Nevada", "Neville", "Newton", "Nga", "Ngan", "Ngoc", "Nguyet", "Nia", "Nichelle", "Nichol", "Nicholas", "Nichole", "Nicholle", "Nick", "Nicki", "Nickie", "Nickolas", "Nickole", "Nicky", "Nicky", "Nicol", "Nicola", "Nicolas", "Nicolasa", "Nicole", "Nicolette", "Nicolle", "Nida", "Nidia", "Niesha", "Nieves", "Nigel", "Niki", "Nikia", "Nikita", "Nikki", "Nikole", "Nila", "Nilda", "Nilsa", "Nina", "Ninfa", "Nisha", "Nita", "Noah", "Noble", "Nobuko", "Noe", "Noel", "Noel", "Noelia", "Noella", "Noelle", "Noemi", "Nohemi", "Nola", "Nolan", "Noma", "Nona", "Nora", "Norah", "Norbert", "Norberto", "Noreen", "Norene", "Noriko", "Norine", "Norma", "Norman", "Norman", "Normand", "Norris", "Nova", "Novella", "Nu", "Nubia", "Numbers", "Numbers", "Nydia", "Nyla", "Obdulia", "Ocie", "Octavia", "Octavio", "Oda", "Odelia", "Odell", "Odell", "Odessa", "Odette", "Odilia", "Odis", "Ofelia", "Ok", "Ola", "Olen", "Olene", "Oleta", "Olevia", "Olga", "Olimpia", "Olin", "Olinda", "Oliva", "Olive", "Oliver", "Olivia", "Ollie", "Ollie", "Olympia", "Oma", "Omar", "Omega", "Omer", "Ona", "Oneida", "Onie", "Onita", "Opal", "Ophelia", "Ora", "Oralee", "Oralia", "Oren", "Oretha", "Orlando", "Orpha", "Orval", "Orville", "Oscar", "Oscar", "Ossie", "Osvaldo", "Oswaldo", "Otelia", "Otha", "Otha", "Otilia", "Otis", "Otto", "Ouida", "Owen", "Ozell", "Ozella", "Ozie", "Prince", "Princess", "Priscila", "Priscilla", "Providencia", "Prudence", "Pura", "Quincy", "Quinn", "Quinn", "Quintin", "Quinton", "Quyen", "Ruthanne", "Ruthe", "Ruthie", "Ryan", "Ryan", "Ryann", "Syble", "Sydney", "Sydney", "Sylvester", "Sylvia", "Sylvie", "Synthia", "Syreeta", "Tyra", "Tyree", "Tyrell", "Tyron", "Tyrone", "Tyson", "Ula", "Ulrike", "Ulysses", "Un", "Una", "Ursula", "Usha", "Ute", "Vada", "Val", "Val", "Vivien", "Vivienne", "Von", "Voncile", "Vonda", "Vonnie", "Wonda", "Woodrow", "Wyatt", "Wynell", "Wynona", "Yun", "Yung", "Yuonne", "Yuri", "Yuriko", "Yvette", "Yvone", "Yvonne", "Zora", "Zoraida", "Zula", "Zulema", "Zulma"]
	FULL_NAME = random.choice(Names_List) + " " + random.choice(Names_List)
	return FULL_NAME
def Random_MD5():
	RAND_MD5 = binascii.hexlify(os.urandom(16))
	return RAND_MD5
def Random_Ticket_ID():
	UpperLetters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
	OnlyNumbers = '0123456789'
	RAND_TICKET_ID = random.choice(UpperLetters) + random.choice(OnlyNumbers) + random.choice(OnlyNumbers) + "-" + random.choice(UpperLetters) + random.choice(OnlyNumbers) + random.choice(OnlyNumbers) + "-" + random.choice(UpperLetters) + random.choice(OnlyNumbers) + random.choice(OnlyNumbers) + "-" + random.choice(UpperLetters) + random.choice(OnlyNumbers) + random.choice(OnlyNumbers)
	return RAND_TICKET_ID
# // ====================================================================================
def Current_Time():
	now = datetime.now()
	CURR_TIME = now.strftime("%H:%M:%S")
	return CURR_TIME
def generator_mix_10(size=10, chars=string.ascii_uppercase + string.digits):
	return ''.join(random.choice(chars) for _ in range(size))
def generator_str_10(size=10, chars=string.ascii_lowercase):
	return ''.join(random.choice(chars) for _ in range(size))
def generator_int_10(size=10, chars=string.digits):
	return ''.join(random.choice(chars) for _ in range(size))
def RND5(size=5, chars=string.ascii_lowercase):
	return ''.join(random.choice(chars) for _ in range(size))
def Get_Random_Letter():
	global Ask_For_Letters
	try:
		FILE = open(Ask_For_Letters, 'r').read().split('=========================================================================================')
		Random_Letter = random.choice(FILE)
	except:
		Random_Letter = open(Ask_For_Letters, 'r').read()
	Random_Letter = Random_Letter.replace('\n', '')
	return Random_Letter
def Get_Random_Sender_Name():
	global Ask_For_Sender_Names
	FILE = open(Ask_For_Sender_Names, 'r').read().split('\n')
	Sender_Name = random.choice(FILE)
	return Sender_Name
def Get_Random_From_Email():
	global Ask_For_From_Emails
	FILE = open(Ask_For_From_Emails, 'r').read().split('\n')
	From_Email = random.choice(FILE)
	return From_Email
def Get_Random_Subject():
	global Ask_For_Subjects
	FILE = open(Ask_For_Subjects, 'r').read().split('\n')
	Subject = random.choice(FILE)
	return Subject
def Get_Random_URL():
	global Ask_For_URLs
	FILE = open(Ask_For_URLs, 'r').read().split('\n')
	PAGE_URL = random.choice(FILE)
	return PAGE_URL
def Get_Random_SMTP():
	FILE = open(Ask_For_SMTPS, 'r').read().split('\n')
	SMTP = random.choice(FILE)
	return SMTP
def ENCODE(TEXT_):
	ENC = TEXT_.encode("UTF-8")
	encoded_text = base64.b64encode(ENC)
	ENCODED = "=?UTF-8?B?" + encoded_text + "?="
	return ENCODED
def ENCRYPT(LETTER_):
	HEXs_ = [" [-]&#x20;", "0[-]&#x30;", "1[-]&#x31;", "2[-]&#x32;", "3[-]&#x33;", "4[-]&#x34;", "5[-]&#x35;", "6[-]&#x36;", "7[-]&#x37;", "8[-]&#x38;", "9[-]&#x39;", "a[-]&#x61;", "b[-]&#x62;", "c[-]&#x63;", "d[-]&#x64;", "e[-]&#x65;", "f[-]&#x66;", "g[-]&#x67;", "h[-]&#x68;", "i[-]&#x69;", "j[-]&#x6A;", "k[-]&#x6B;", "l[-]&#x6C;", "m[-]&#x6D;", "n[-]&#x6E;", "o[-]&#x6F;", "p[-]&#x70;", "q[-]&#x71;", "r[-]&#x72;", "s[-]&#x73;", "t[-]&#x74;", "u[-]&#x75;", "v[-]&#x76;", "w[-]&#x77;", "x[-]&#x78;", "y[-]&#x79;", "z[-]&#x7A;", "A[-]&#x41;", "B[-]&#x42;", "C[-]&#x43;", "D[-]&#x44;", "E[-]&#x45;", "F[-]&#x46;", "G[-]&#x47;", "H[-]&#x48;", "I[-]&#x49;", "J[-]&#x4A;", "K[-]&#x4B;", "L[-]&#x4C;", "M[-]&#x4D;", "N[-]&#x4E;", "O[-]&#x4F;", "P[-]&#x50;", "Q[-]&#x51;", "R[-]&#x52;", "S[-]&#x53;", "T[-]&#x54;", "U[-]&#x55;", "V[-]&#x56;", "W[-]&#x57;", "X[-]&#x58;", "Y[-]&#x59;", "Z[-]&#x5A;", "@[-]&#x40;", "#[-]&#x23;", "$[-]&#x24;", "%[-]&#x25;", "![-]&#x21;", "?[-]&#x3F;", ",[-]&#x2C;", ".[-]&#x2E;", "*[-]&#x2A;", "_[-]&#x5F;", "+[-]&#x2B;", "=[-]&#x3D;", "-[-]&#x2D;", "\[-]&#x5C;", ":[-]&#x3A;", "/[-]&#x2F;", "|[-]&#x7C;", "'[-]&#x27;", "([-]&#x28;", ")[-]&#x29;", "[[-]&#x5B;", "][-]&#x5D;", "{[-]&#x7B;", "}[-]&#x7D;"]
	COUNT = LETTER_.count("[X]")
	COUNT = COUNT / 2
	NEW_LETTER = LETTER_
	DONE = 1
	for i in xrange(COUNT):
	  SENTENCE = LETTER_.split("[X]")[DONE].split("[X]")[0]
	  XSENTENCE = ""
	  #print SENTENCE
	  for Ltr in SENTENCE:
		for Try in HEXs_:
		  Main, Replacable = Try.split("[-]")
		  if Ltr == Main:
			XSENTENCE = XSENTENCE+Replacable
		  else:
			pass
	  DONE+=2
	  NEW_LETTER = NEW_LETTER.replace(SENTENCE, XSENTENCE)
	NEW_LETTER = NEW_LETTER.replace("[X]", "")
	return NEW_LETTER
def ENCRYPT2(LETTER_):
	COUNT = LETTER_.count("[X]")
	COUNT = COUNT / 2
	NEW_LETTER = LETTER_
	DONE = 1
	for i in xrange(COUNT):
		SENTENCE = LETTER_.split("[X]")[DONE].split("[X]")[0]
		XIAO = SENTENCE.split(" ")
		XIAOO = []
		for ELM in XIAO:
			ELM = ELM.replace(ELM, ELM+"<span style='font-size: 0px;'>"+RND5()+"</span>")
			XIAOO.append(ELM)
		XSENTENCE = " ".join(XIAOO)
		DONE+=2
		NEW_LETTER = NEW_LETTER.replace(SENTENCE, XSENTENCE)
	NEW_LETTER = NEW_LETTER.replace("[X]", "")
	return NEW_LETTER
def Short(SITE_URL_):
	while 1:
		data = 'url={}'.format(SITE_URL_)
		headers = {
			'accept': 'application/json, text/javascript, */*; q=0.01',
			'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
			'cookie': '_xsrf=d4bcdddd3f1c41dfbc78ddc5ca14e550; anon_u=cHN1X18yNTdkMDNlZi00NDliLTRkYmUtYTU1MS0zM2UxMDg4N2I1OTY=|1609368482|a827efb124aeebff43ab7c7e083c4c5195584af4; optimizelyEndUserId=oeu1609368481812r0.24567796502612782; _mkto_trk=id:754-KBJ-733&token:_mch-bitly.com-1609368482434-99663; _fbp=fb.1.1609368482561.1193016587; _ga=GA1.2.459630534.1609368483; _gid=GA1.2.697822726.1609368483; cookie_banner=1; wow-modal-id-2=yes; anon_shortlinks=https://bit.ly/38GBAEY,https://bit.ly/35e5xf1,https://bit.ly/3ht6eWB,https://bit.ly/3mZ7Yb1,https://bit.ly/3hvPcar,https://bit.ly/385u73z,https://bit.ly/38LjySd,https://bit.ly/2WUPRbV,https://bit.ly/3mV0LZK,https://bit.ly/2JuyOKu,https://bit.ly/3rQW4E2,https://bit.ly/3o6vLY4,https://bit.ly/3pyOpYU',
			'origin': 'https://bitly.com',
			'referer': 'https://bitly.com/',
			'sec-ch-ua': '"Google Chrome";v="87", " Not;A Brand";v="99", "Chromium";v="87"',
			'sec-ch-ua-mobile': '?0',
			'sec-fetch-dest': 'empty',
			'sec-fetch-mode': 'cors',
			'sec-fetch-site': 'same-origin',
			'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36',
			'x-requested-with': 'XMLHttpRequest',
			'x-xsrftoken': 'd4bcdddd3f1c41dfbc78ddc5ca14e550'
		}
		r = requests.post("https://bitly.com/data/anon_shorten", data=data, headers=headers)
		src = r.content
		if 'status_code": 200' in src:
			SHORTEN_URL = src.split('"link": "')[1].split('"')[0]
			return SHORTEN_URL
			break
		else:
			pass
def AutoFill(STRING):
	if '@CHASE' in STRING: STRING = '"{} <{}>"'.format(STRING.split(" @CHASE")[0], "no.reply.alerts@chase.com")
	if '@CITIZEN' in STRING: STRING = '"{} <{}>"'.format(STRING.split(" @CITIZEN")[0], "do-not-reply@paymyloan.citizensbank.com")
	if '@WELLS' in STRING: STRING = '"{} <{}>"'.format(STRING.split(" @WELLS")[0], "alerts@notify.wellsfargo.com")
	if '@REGIONS' in STRING: STRING = '"{} <{}>"'.format(STRING.split(" @REGIONS")[0], "email@alert.regions.com")
	if '@BOA' in STRING: STRING = '"{} <{}>"'.format(STRING.split(" @BOA")[0], "bankofamerica@emcom.bankofamerica.com")
	if '@NAVYFEDERAL' in STRING: STRING = '"{} <{}>"'.format(STRING.split(" @NAVYFEDERAL")[0], "mynavyfederal@response.nfcu.org")
	if '@CREDITONE' in STRING: STRING = '"{} <{}>"'.format(STRING.split(" @CREDITONE")[0], "donotreply@creditonemail.com")
	if '@CASHAPP' in STRING: STRING = '"{} <{}>"'.format(STRING.split(" @CASHAPP")[0], "cash@square.com")
	if '@PAYPAL' in STRING: STRING = '"{} <{}>"'.format(STRING.split(" @PAYPAL")[0], "paypal@mail.paypal.com")
	if '@AMAZON' in STRING: STRING = '"{} <{}>"'.format(STRING.split(" @AMAZON")[0], "store-news@amazon.com")
	if '@EBAY' in STRING: STRING = '"{} <{}>"'.format(STRING.split(" @EBAY")[0], "ebay@ebay.com")
	if '@APPLE' in STRING: STRING = '"{} <{}>"'.format(STRING.split(" @APPLE")[0], "appstore@insideapple.apple.com")
	if '@WALMART' in STRING: STRING = '"{} <{}>"'.format(STRING.split(" @WALMART")[0], "help@walmart.com")
	if '@NETFLIX' in STRING: STRING = '"{} <{}>"'.format(STRING.split(" @NETFLIX")[0], "info@mailer.netflix.com")
	if '@MICROSOFT' in STRING: STRING = '"{} <{}>"'.format(STRING.split(" @MICROSOFT")[0], "microsoftstore@microsoftstoreemail.com")
	if '@BLOCKCHAIN' in STRING: STRING = '"{} <{}>"'.format(STRING.split(" @BLOCKCHAIN")[0], "notify@wallet-tx.blockchain.com")
	if '@HTML_CHASE' in STRING: STRING = '{} <{}>'.format(STRING.split(" @HTML_CHASE")[0], "<no-reply@alertsp.chase.com>")
	if '@HTML_APPLE' in STRING: STRING = '{} <{}>'.format(STRING.split(" @HTML_APPLE")[0], "<your_order_US@orders.apple.com>")
	if '@HTML_COINBASE' in STRING: STRING = '{} <{}>'.format(STRING.split(" @HTML_COINBASE")[0], "<no-reply@coinbase.com>")
	if '@HTML_EBAY' in STRING: STRING = '{} <{}>'.format(STRING.split(" @HTML_EBAY")[0], "<ebay@reply.ebay.com>")
	if '@HTML_AMAZON' in STRING: STRING = '{} <{}>'.format(STRING.split(" @HTML_AMAZON")[0], "<order-update@amazon.com>")
	if 'URL_TO_GO' in STRING: STRING = STRING.replace('URL_TO_GO', Get_Random_URL());
	if 'RANDOM_IP_GEN' in STRING: STRING = STRING.replace('RANDOM_IP_GEN', Random_IP());
	if 'OS_GEN' in STRING: STRING = STRING.replace('OS_GEN', Random_OS());
	if 'CURR_DATE' in STRING: STRING = STRING.replace('CURR_DATE', Current_Date());
	if 'COUNTRY_GEN' in STRING: STRING = STRING.replace('COUNTRY_GEN', Random_Country());
	if 'EMAIL_GEN' in STRING: STRING = STRING.replace('EMAIL_GEN', Random_Email());
	if 'BROWSER_GEN' in STRING: STRING = STRING.replace('BROWSER_GEN', Random_Browser());
	if 'MIX_10_GEN' in STRING: STRING = STRING.replace('MIX_10_GEN', generator_mix_10());
	if 'STR_10_GEN' in STRING: STRING = STRING.replace('STR_10_GEN', generator_str_10());
	if 'INT_10_GEN' in STRING: STRING = STRING.replace('INT_10_GEN', generator_int_10());
	if 'SMTP_LOG_GEN' in STRING: STRING = STRING.replace('SMTP_LOG_GEN', SMTP_LOG_GEN);
	if 'FIRST_NAME_GEN' in STRING: STRING = STRING.replace('FIRST_NAME_GEN', Random_Name());
	if 'FULL_NAME_GEN' in STRING: STRING = STRING.replace('FULL_NAME_GEN', Random_NameX());
	if 'RAND_MD5' in STRING: STRING = STRING.replace('RAND_MD5', Random_MD5());
	if 'RAND_TICKET_ID' in STRING: STRING = STRING.replace('RAND_TICKET_ID', Random_Ticket_ID());
	if 'CURR_TIME' in STRING: STRING = STRING.replace('CURR_TIME', Current_Time());
	if 'FROM_MAIL_GEN' in STRING: STRING = STRING.replace('FROM_MAIL_GEN', FROM_MAIL_GEN);
	if 'MAIL_TO_GEN' in STRING: STRING = STRING.replace('MAIL_TO_GEN', TO_);
	if 'SMTP_USER_GEN' in STRING: STRING = STRING.replace('SMTP_USER_GEN', SMTP_USER_GEN);
	if 'SMTP_DOMAIN_GEN' in STRING: STRING = STRING.replace('SMTP_DOMAIN_GEN', SMTP_DOMAIN_GEN);
	if 'USER_TO_GEN' in STRING: STRING = STRING.replace('USER_TO_GEN', USER_TO_GEN);
	if 'DOMAIN_TO_GEN' in STRING: STRING = STRING.replace('DOMAIN_TO_GEN', DOMAIN_TO_GEN);
	return STRING
def AutoFillLetter(STRING, SMTP_LOG_GEN, FROM_MAIL_GEN, TO_, SMTP_USER_GEN, SMTP_DOMAIN_GEN, USER_TO_GEN, DOMAIN_TO_GEN):
	if '@CHASE' in STRING: STRING = '"{} <{}>"'.format(STRING.split(" @CHASE")[0], "no.reply.alerts@chase.com")
	if '@CITIZEN' in STRING: STRING = '"{} <{}>"'.format(STRING.split(" @CITIZEN")[0], "do-not-reply@paymyloan.citizensbank.com")
	if '@WELLS' in STRING: STRING = '"{} <{}>"'.format(STRING.split(" @WELLS")[0], "alerts@notify.wellsfargo.com")
	if '@REGIONS' in STRING: STRING = '"{} <{}>"'.format(STRING.split(" @REGIONS")[0], "email@alert.regions.com")
	if '@BOA' in STRING: STRING = '"{} <{}>"'.format(STRING.split(" @BOA")[0], "bankofamerica@emcom.bankofamerica.com")
	if '@NAVYFEDERAL' in STRING: STRING = '"{} <{}>"'.format(STRING.split(" @NAVYFEDERAL")[0], "mynavyfederal@response.nfcu.org")
	if '@CREDITONE' in STRING: STRING = '"{} <{}>"'.format(STRING.split(" @CREDITONE")[0], "donotreply@creditonemail.com")
	if '@CASHAPP' in STRING: STRING = '"{} <{}>"'.format(STRING.split(" @CASHAPP")[0], "cash@square.com")
	if '@PAYPAL' in STRING: STRING = '"{} <{}>"'.format(STRING.split(" @PAYPAL")[0], "paypal@mail.paypal.com")
	if '@AMAZON' in STRING: STRING = '"{} <{}>"'.format(STRING.split(" @AMAZON")[0], "store-news@amazon.com")
	if '@EBAY' in STRING: STRING = '"{} <{}>"'.format(STRING.split(" @EBAY")[0], "ebay@ebay.com")
	if '@APPLE' in STRING: STRING = '"{} <{}>"'.format(STRING.split(" @APPLE")[0], "appstore@insideapple.apple.com")
	if '@WALMART' in STRING: STRING = '"{} <{}>"'.format(STRING.split(" @WALMART")[0], "help@walmart.com")
	if '@NETFLIX' in STRING: STRING = '"{} <{}>"'.format(STRING.split(" @NETFLIX")[0], "info@mailer.netflix.com")
	if '@MICROSOFT' in STRING: STRING = '"{} <{}>"'.format(STRING.split(" @MICROSOFT")[0], "microsoftstore@microsoftstoreemail.com")
	if '@BLOCKCHAIN' in STRING: STRING = '"{} <{}>"'.format(STRING.split(" @BLOCKCHAIN")[0], "notify@wallet-tx.blockchain.com")
	if '@HTML_CHASE' in STRING: STRING = '{} <{}>'.format(STRING.split(" @HTML_CHASE")[0], "<no-reply@alertsp.chase.com>")
	if '@HTML_APPLE' in STRING: STRING = '{} <{}>'.format(STRING.split(" @HTML_APPLE")[0], "<your_order_US@orders.apple.com>")
	if '@HTML_COINBASE' in STRING: STRING = '{} <{}>'.format(STRING.split(" @HTML_COINBASE")[0], "<no-reply@coinbase.com>")
	if '@HTML_EBAY' in STRING: STRING = '{} <{}>'.format(STRING.split(" @HTML_EBAY")[0], "<ebay@reply.ebay.com>")
	if '@HTML_AMAZON' in STRING: STRING = '{} <{}>'.format(STRING.split(" @HTML_AMAZON")[0], "<order-update@amazon.com>")
	if 'URL_TO_GO' in STRING: STRING = STRING.replace('URL_TO_GO', Get_Random_URL());
	if 'RANDOM_IP_GEN' in STRING: STRING = STRING.replace('RANDOM_IP_GEN', Random_IP());
	if 'OS_GEN' in STRING: STRING = STRING.replace('OS_GEN', Random_OS());
	if 'CURR_DATE' in STRING: STRING = STRING.replace('CURR_DATE', Current_Date());
	if 'COUNTRY_GEN' in STRING: STRING = STRING.replace('COUNTRY_GEN', Random_Country());
	if 'EMAIL_GEN' in STRING: STRING = STRING.replace('EMAIL_GEN', Random_Email());
	if 'BROWSER_GEN' in STRING: STRING = STRING.replace('BROWSER_GEN', Random_Browser());
	if 'MIX_10_GEN' in STRING: STRING = STRING.replace('MIX_10_GEN', generator_mix_10());
	if 'STR_10_GEN' in STRING: STRING = STRING.replace('STR_10_GEN', generator_str_10());
	if 'INT_10_GEN' in STRING: STRING = STRING.replace('INT_10_GEN', generator_int_10());
	if 'SMTP_LOG_GEN' in STRING: STRING = STRING.replace('SMTP_LOG_GEN', SMTP_LOG_GEN);
	if 'FIRST_NAME_GEN' in STRING: STRING = STRING.replace('FIRST_NAME_GEN', Random_Name());
	if 'FULL_NAME_GEN' in STRING: STRING = STRING.replace('FULL_NAME_GEN', Random_NameX());
	if 'RAND_MD5' in STRING: STRING = STRING.replace('RAND_MD5', Random_MD5());
	if 'RAND_TICKET_ID' in STRING: STRING = STRING.replace('RAND_TICKET_ID', Random_Ticket_ID());
	if 'CURR_TIME' in STRING: STRING = STRING.replace('CURR_TIME', Current_Time());
	if 'FROM_MAIL_GEN' in STRING: STRING = STRING.replace('FROM_MAIL_GEN', FROM_MAIL_GEN);
	if 'MAIL_TO_GEN' in STRING: STRING = STRING.replace('MAIL_TO_GEN', TO_);
	if 'SMTP_USER_GEN' in STRING: STRING = STRING.replace('SMTP_USER_GEN', SMTP_USER_GEN);
	if 'SMTP_DOMAIN_GEN' in STRING: STRING = STRING.replace('SMTP_DOMAIN_GEN', SMTP_DOMAIN_GEN);
	if 'USER_TO_GEN' in STRING: STRING = STRING.replace('USER_TO_GEN', USER_TO_GEN);
	if 'DOMAIN_TO_GEN' in STRING: STRING = STRING.replace('DOMAIN_TO_GEN', DOMAIN_TO_GEN);
	return STRING
def REPORT_DIS(API_KEY):
	print "botato"
def GMASS_TEST(SMTP_LINE, Security):
	global Ask_For_MailList, TOTAL_LIST_
	MAIL_TO = open(Ask_For_MailList, "r").read()
	HOST, PORT, USER, PASS, MAILFROM = SMTP_LINE.split("|")
	session = requests.Session()
	# Auto = a
	# None = n
	# SslOnConnect = s
	# StartTls = t
	# StartTlsWhenAvailable = tv
	if Security == "a": Security = "Auto";
	if Security == "n": Security = "None";
	if Security == "s": Security = "SslOnConnect";
	if Security == "t": Security = "StartTls";
	if Security == "tv": Security = "StartTlsWhenAvailable";
	if "+" in PASS: PASS = PASS.replace("+", "%2B")
	if "/" in PASS: PASS = PASS.replace("/", "%2F")
	headers = {
		'Accept': 'application/json, text/javascript, */*; q=0.01',
		'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
		'Cookie': 'GMassUniqueID=2817d566-c9f4-43df-bb13-3106821069cd; GMassAffiliateID=; GMassLanding=https://www.gmass.co/smtp-test; GMassReferrer=https://www.google.com/; GMassDate=2021-04-24T01:44:57.071Z; _rdt_uuid=1619228697223.0b6b294b-9fbc-427c-bd84-1ca465894082; _ga=GA1.2.40042028.1619228697; _fbp=fb.1.1622763267374.546797804; _hjid=fec15c26-84e7-4eae-ac42-e15c5f039d4f; drift_aid=09f34602-c7be-48c8-a80f-5fd0bf417284; driftt_aid=09f34602-c7be-48c8-a80f-5fd0bf417284; _gcl_au=1.1.512042522.1624029769; GMassStopNotifications=false; _gid=GA1.2.1834607266.1629313644; _hjIncludedInPageviewSample=1; _hjAbsoluteSessionInProgress=0; drift_campaign_refresh=42a79719-1360-449a-976e-31d1487144dd',
		'Host': 'www.gmass.co',
		'Origin': 'https://www.gmass.co',
		'Referer': 'https://www.gmass.co/smtp-test',
		'sec-ch-ua': '"Chromium";v="92", " Not A;Brand";v="99", "Google Chrome";v="92"',
		'sec-ch-ua-mobile': '?0',
		'Sec-Fetch-Dest': 'empty',
		'Sec-Fetch-Mode': 'cors',
		'Sec-Fetch-Site': 'same-origin',
		'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Safari/537.36',
		'X-Requested-With': 'XMLHttpRequest',
	}
	data = "SmtpServer={}&port={}&sso={}&username={}&password={}&from={}&to={}".format(HOST, PORT, Security, USER, PASS, MAILFROM, MAIL_TO)
	r = session.post("https://www.gmass.co/Smtp/CreateTest", headers=headers, data=data)
	SRC = r.content
	EVAL_SRC = eval(SRC)
	TOKEN_ = SRC.replace('"', '')
	time.sleep(6)
	R = session.get("https://www.gmass.co/Smtp/TestStatus?testId="+TOKEN_)
	SRC_ = R.content
	if '<div class="error">' in SRC_: SRC_ = SRC_.replace('<div class="error">', '')
	if '<pre style="background-color: black">' in SRC_: SRC_ = SRC_.replace('<pre style="background-color: black">', '')
	if '<div class="neither">' in SRC_: SRC_ = SRC_.replace('<div class="neither">', '')
	if '<div class="server">' in SRC_: SRC_ = SRC_.replace('<div class="server">', '')
	if '<div class="client">' in SRC_: SRC_ = SRC_.replace('<div class="client">', '')
	if '<div class="neither">' in SRC_: SRC_ = SRC_.replace('<div class="neither">', '')
	if '</div>' in SRC_: SRC_ = SRC_.replace('</div>', '')
	if '</pre>' in SRC_: SRC_ = SRC_.replace('</pre>', '')
	if '&lt;&lt; ' in SRC_: SRC_ = SRC_.replace('&lt;&lt; ', '')
	if '&gt;&gt; ' in SRC_: SRC_ = SRC_.replace('&gt;&gt; ', '')
	if '		' in SRC_: SRC_ = SRC_.replace('		', '')
	print SRC_
def Mailers(Email):
	global DESKTOP_PATH, MAILERS_FILE, M_ENCLETTER, M_ENCSUBJECT, M_DELAY, M_THREADS
	global TOTAL_VAL, TOTAL_BAD, TOTAL_LIST_
	MAILERS			   = []
	MailersPartInFile	 = MAILERS_FILE.split("URLS:")[1].split("=================================")[0]
	MailersCount		  = MailersPartInFile.count("->") #INT
	X = 1
	for i in xrange(MailersCount):
		Mlr = MailersPartInFile.split("-> ")[X].split("\n")[0]
		MAILERS.append(Mlr)
		if X != MailersCount:
			X+=1
		else:
			break
	Current_Used_Mailer   = random.choice(MAILERS)
	Current_Used_Mailer, Current_Used_MailFrom = Current_Used_Mailer.split(" : ")
	Current_Used_Mailer   = AutoFill(Current_Used_Mailer)
	Current_Used_MailFrom = AutoFill(Current_Used_MailFrom)
	Sender_Name = AutoFill(Get_Random_Sender_Name())
	Subject	 = AutoFill(Get_Random_Subject())
	Letter	  = AutoFill(Get_Random_Letter())
	URL_TO_GO   = AutoFill(Get_Random_URL())
	if M_ENCSUBJECT == "y" or M_ENCSUBJECT == "Y":
		Subject = ENCODE(Subject)
		Sender_Name = ENCODE(Sender_Name)
	else:
		pass
	if "UTF" in M_ENCLETTER:
		Letter = ENCRYPT(Letter)
	elif "DIS" in M_ENCLETTER:
		Letter = ENCRYPT2(Letter)
	else:
		Letter = Letter.replace("[X]", "")
	if "64" in M_ENCLETTER:
		MailerEncode = "base64"
	else:
		MailerEncode = "8bit"
		pass
	data = {
		"action": "score",
		"senderEmail": Current_Used_MailFrom,
		"senderName": Sender_Name,
		"attachment[]": "(binary)",
		"replyTo": "",
		"subject": Subject,
		"messageLetter": Letter,
		"emailList": Email,
		"messageType": "1",
		"charset": "UTF-8",
		"encode": MailerEncode,
		"action": "send"
	}
	headers = {
		"accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
		"accept-encoding": "gzip, deflate, br",
		"accept-language": "en-US,en;q=0.9",
		"cache-control": "max-age=0",
		"content-length": "1406",
		'sec-ch-ua': '" Not;A Brand";v="99", "Google Chrome";v="91", "Chromium";v="91"',
		"sec-ch-ua-mobile": "?0",
		"sec-fetch-dest": "document",
		"sec-fetch-mode": "navigate",
		"sec-fetch-site": "same-origin",
		"sec-fetch-user": "?1",
		"upgrade-insecure-requests": "1",
		"user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36" }
	r = requests.post(Current_Used_Mailer, data=data, headers=headers, verify=False)
	if '<span class="label label-success">Ok</span>' in r.content:
		print "%s%s\t[ + ] Email Sent : {}, Mailer: {}%s".format(TO_, Current_Used_Mailer) % (fg(22), bg(0), attr(0))
		Successfully_Sent = open(DESKTOP_PATH+'\Mailers_Successfully_Sent.txt','a+')
		Successfully_Sent.write('{}\n'.format(Email))
		Successfully_Sent.close()
		TOTAL_VAL+=1
		TOTAL_LIST_-=1
		os.system("title "+ "[$] Bagoza SNDR V3 [Sent: {}] [Failed: {}] [Remaining: {}]".format(str(TOTAL_VAL), str(TOTAL_BAD), str(TOTAL_LIST_)))
	else:
		print "%s%s\t[ - ] Sending Failed : {}, Mailer: {}%s".format(TO_, Current_Used_Mailer) % (fg(52), bg(0), attr(0))
		Failed_Sending = open(DESKTOP_PATH+'\Mailers_Failed_Sending.txt','a+')
		Failed_Sending.write('{}\n'.format(Email))
		Failed_Sending.close()
		TOTAL_BAD+=1
		os.system("title "+ "[$] Bagoza SNDR V3 [Sent: {}] [Failed: {}] [Remaining: {}]".format(str(TOTAL_VAL), str(TOTAL_BAD), str(TOTAL_LIST_)))
	if M_DELAY != "n":
		time.sleep(int(M_DELAY))
	else:
		pass
def SEND(TO_):
	global S_TYPE, S_TLS, S_DELAY, S_SHORTING, S_ENCSUB, S_LETTERENC, S_ATTACHES, S_RETRYFAILED, S_SENDINGTIME, S_THREADS, M_ENCLETTER, M_ENCSUBJECT, M_DELAY, HEADERS_FILE_
	global TOTAL_VAL, TOTAL_BAD, TOTAL_LIST_

	# // Getting SMTP:
	# ///////////////////
	try:
		SMTP_HOST, SMTP_PORT, SMTP_USERNAME, SMTP_PASSWORD, SMTP_MAILFROM, SMTP_TLS = Get_Random_SMTP().split("|")
		S_TLS = SMTP_TLS
	except:
		SMTP_HOST, SMTP_PORT, SMTP_USERNAME, SMTP_PASSWORD, SMTP_MAILFROM = Get_Random_SMTP().split("|")
	SMTP_MAILFROM   = AutoFill(SMTP_MAILFROM)
	SMTP_GEN_XXX	= SMTP_MAILFROM.split("@")
	SMTP_USER_GEN   = AutoFill(SMTP_GEN_XXX[0])
	SMTP_DOMAIN_GEN = AutoFill(SMTP_GEN_XXX[1])
	USER_TO_XXX	 = TO_.split("@")
	USER_TO_GEN	 = AutoFill(USER_TO_XXX[0])
	DOMAIN_TO_GEN   = AutoFill(USER_TO_XXX[1])
	# ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	# Getting Constant Variables:
	# ////////////////////////////////
	_NAME_	  = AutoFill(Get_Random_Sender_Name())
	_SUBJECT_ = AutoFill(Get_Random_Subject())
	_URL_	  = AutoFill(Get_Random_URL())
	_LETTER_  = AutoFillLetter(Get_Random_Letter(), SMTP_USERNAME, SMTP_MAILFROM, TO_, SMTP_USER_GEN, SMTP_DOMAIN_GEN, USER_TO_GEN, DOMAIN_TO_GEN)
	# ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	# // Sending STEP:
	# ///////////////////
	socket.setdefaulttimeout(15)
	msg = MIMEMultipart()
	if S_ENCSUB == "y":
		_SUBJECT_ = ENCODE(_SUBJECT_)
		_NAME_ = ENCODE(_NAME_)
	msg['From'] = "{} <{}>".format(_NAME_, SMTP_MAILFROM)
	msg['To'] = "{}".format(TO_)
	msg['Subject'] = "{}".format(_SUBJECT_)

	# // Sending Headers
	# ///////////////////
	HEADERS_FILE = open(HEADERS_FILE_, "r").read()
	if HEADERS_FILE == "" and ":" not in HEADERS_FILE:
		pass
	else:
		HEADERS_FILE_LINES = open(HEADERS_FILE_, "r").read().split('\n')
		for Line in HEADERS_FILE_LINES:
			Left, Right = Line.split(': ')
			msg.add_header(Left, Right)

	# // Completing The Others Defs:
	# //////////////////////////////////
	_LETTER_ = '''{}'''.format(_LETTER_)
	if S_LETTERENC == "n":
		_LETTER_ = _LETTER_.replace("[X]", "")
		msg.attach(MIMEText(_LETTER_, S_TYPE))
	else:
		if "UTF" in S_LETTERENC:
			_LETTER_ = ENCRYPT(_LETTER_)
		elif "DIS" in S_LETTERENC:
			_LETTER_ = ENCRYPT2(_LETTER_)
		else:
			pass
		if S_LETTERENC == "SES64":
			msg.attach(MIMEText(_LETTER_, S_TYPE, 'UTF-8'))
		elif "64" in S_LETTERENC:
			msg.attach(MIMEText(_LETTER_, S_TYPE, 'base64'))
		else:
			msg.attach(MIMEText(_LETTER_, S_TYPE))
			pass
	if S_ATTACHES != "n":
		DIRECTION = S_ATTACHES
		FILE_NAME = DIRECTION.split("\\")[-1]
		FILE_TYPE = FILE_NAME.split('.')[1]
		FILE_NAME = AutoFill(FILE_NAME)
		with open(S_ATTACHES, "rb") as attachment:
			p = MIMEApplication(attachment.read(),_subtype=FILE_TYPE)	
			p.add_header('Content-Disposition', "attachment; filename= %s" % FILE_NAME) 
			msg.attach(p)
	else:
		pass
	try:
		server = smtplib.SMTP(SMTP_HOST, int(SMTP_PORT))
		if S_TLS == "y":
			server.ehlo()
			server.starttls()
		else:
			pass
		server.login(SMTP_USERNAME, SMTP_PASSWORD)
		a = server.sendmail(msg['From'], msg['To'], msg.as_string())
		#server.quit()
		print "%s%s\t[ + ] Email Sent : {}%s".format(TO_) % (fg(22), bg(0), attr(0))
		Successfully_Sent = open(DESKTOP_PATH+'\SMTPS_Successfully_Sent.txt','a+')
		Successfully_Sent.write('{}\n'.format(TO_))
		Successfully_Sent.close()
		TOTAL_VAL+=1
		TOTAL_LIST_-=1
		os.system("title "+ "[$] Bagoza SNDR V3 [Sent: {}] [Failed: {}] [Remaining: {}]".format(str(TOTAL_VAL), str(TOTAL_BAD), str(TOTAL_LIST_)))
		return True
	except Exception as ERR_:
		print "%s%s\t[ - ] Sending Failed : {}, Error: {}%s".format(TO_, ERR_) % (fg(52), bg(0), attr(0))
		Failed_Sending = open(DESKTOP_PATH+'\SMTPS_Failed_Sending.txt','a+')
		Failed_Sending.write('{}\n'.format(TO_))
		Failed_Sending.close()
		TOTAL_BAD+=1
		os.system("title "+ "[$] Bagoza SNDR V3 [Sent: {}] [Failed: {}] [Remaining: {}]".format(str(TOTAL_VAL), str(TOTAL_BAD), str(TOTAL_LIST_)))
		return False

# // Start Working:
# ////////////////////
while 1:
	SETTINGS_	  = open(USER_SETTINGS_, "r").read()
	S_TYPE	 	  = SETTINGS_.split("Type: ")[1].split("\n")[0]
	S_TLS		  = SETTINGS_.split("Tls: ")[1].split("\n")[0]
	S_DELAY	      = SETTINGS_.split("Delay: ")[1].split("\n")[0]
	S_SHORTING	  = SETTINGS_.split("Short: ")[1].split("\n")[0]
	S_ENCSUB	  = SETTINGS_.split("NameSubjectEnc: ")[1].split("\n")[0]
	S_LETTERENC   = SETTINGS_.split("LettersEnc: ")[1].split("\n")[0]
	S_ATTACHES	  = SETTINGS_.split("AttachmentFile: ")[1].split("\n")[0]
	S_RETRYFAILED = SETTINGS_.split("RetryFailed: ")[1].split("\n")[0]
	S_SENDINGTIME = SETTINGS_.split("Time: ")[1].split("\n")[0]
	S_THREADS	  = SETTINGS_.split("MultiThreading: ")[1].split("\n")[0]
	M_ENCLETTER   = MAILERS_FILE.split("LetterEncryption : ")[1].split("\n")[0]
	M_ENCSUBJECT  = MAILERS_FILE.split("NameSubMlrEncryption : ")[1].split("\n")[0]
	M_DELAY	      = MAILERS_FILE.split("MailerSendingDelay : ")[1].split("\n")[0]
	M_THREADS	  = MAILERS_FILE.split("MailerMultiThreads : ")[1].split("\n")[0]
	TOTAL_LIST_   = len(open(Ask_For_MailList, "r").read().split("\n"))
	print TOTAL_LIST_
	REPORTER_	 = "OFF" #IM NOT GONNA RECIEVE ANYTHING BITCHES
	TOTAL_VAL	 = 0
	TOTAL_BAD	 = 0
	os.system('cls')
	os.system("title "+ "Bagoza SNDR V3.exe  #~/ ")
	print "%s%s\n\t     / \%s" % (fg(22), bg(0), attr(0)); time.sleep(0.1)
	print "%s%s\t    / _ \%s" % (fg(22), bg(0), attr(0)); time.sleep(0.1)
	print "%s%s\t   | / \ |%s" % (fg(22), bg(0), attr(0)); time.sleep(0.1)
	print "%s%s\t   ||   || _______%s" % (fg(22), bg(0), attr(0)); time.sleep(0.1)
	print "%s%s\t   ||   || |\     \%s" % (fg(22), bg(0), attr(0)); time.sleep(0.1)
	print "%s%s\t   ||   || ||\     \%s" % (fg(22), bg(0), attr(0)); time.sleep(0.1)
	print "%s%s\t   ||   || || \    |	  ____                              ______              _ _ _       %s" % (fg(22), bg(0), attr(0)); time.sleep(0.1)
	print "%s%s\t   ||   || ||  \__/	 |  _ \                            |  ____|            (_) (_)      %s" % (fg(22), bg(0), attr(0)); time.sleep(0.1)
	print "%s%s\t   ||   || ||   ||	 | |_) | __ _  __ _  ___ ______ _  | |__ __ _ _ __ ___  _| |_  __ _ %s" % (fg(22), bg(0), attr(0)); time.sleep(0.1)
	print "%s%s\t    \\_/ \_/ \_//	 |  _ < / _` |/ _` |/ _ \_  / _` | |  __/ _` | '_ ` _ \| | | |/ _` |%s" % (fg(22), bg(0), attr(0)); time.sleep(0.1)
	print "%s%s\t   /   _     _   \	 | |_) | (_| | (_| | (_) / / (_| | | | | (_| | | | | | | | | | (_| |%s" % (fg(22), bg(0), attr(0)); time.sleep(0.1)
	print "%s%s\t  /               \	 |____/ \__,_|\__, |\___/___\__,_| |_|  \__,_|_| |_| |_|_|_|_|\__,_|%s" % (fg(22), bg(0), attr(0)); time.sleep(0.1)
	print "%s%s\t  |    O     O    |	               __/ |                                                %s" % (fg(22), bg(0), attr(0)); time.sleep(0.1)
	print "%s%s\t  |   \  ___  /   |	              |___/                                                 %s" % (fg(22), bg(0), attr(0)); time.sleep(0.1)
	print "%s%s\t /     \ \_/ /     \%s" % (fg(22), bg(0), attr(0)); time.sleep(0.1)
	print "%s%s\t/  -----  |  --\    \	 Nothing Is More Important Than Family%s" % (fg(22), bg(0), attr(0)); time.sleep(0.1)
	print "%s%s\t|     \__/|\__/ \   |	 Contact Admin @T.ME/GoFuckYourSelfHater%s" % (fg(22), bg(0), attr(0)); time.sleep(0.1)
	print "%s%s\t\       |_|_|       /	 Visit bagozasndr.com%s" % (fg(22), bg(0), attr(0)); time.sleep(0.1)
	print "%s%s\t \_____       _____/	 Bagoza V3.exe%s" % (fg(22), bg(0), attr(0)); time.sleep(0.1)
	print "%s%s\t       \     /		 U: Fuck The Haters%s" % (fg(22), bg(0), attr(0)); time.sleep(0.1)
	print "%s%s\t       |     |\n\n%s" % (fg(22), bg(0), attr(0)); time.sleep(0.1)
	Q = raw_input("%s%s\tChoose [Send/maileR/Hlt/Gmass] #~/ %s" % (fg(22), bg(0), attr(0)))
	print ""
	XINO = open(Ask_For_MailList, "r").read().split("\n")
	if TOTAL_LIST_ > 49999:
		print "%s%s\t[ - ] Use List Less Than 49999 Lines Bro.%s" % (fg(52), bg(0), attr(0))
		time.sleep(500000)
	else:
		if REPORTER_ == "ON":
			#REPORT_DIS("1616506366:AAHMIzirI-wZ8ARl_XWsE0X7LH056CwCXkE")
			print "reporter on"
		else:
			pass
		SMTPS__ = open(Ask_For_SMTPS, "r").read().split("\n")
	USERS__ = open(Ask_For_MailList, "r").read().split("\n")
	if Q == "s" or Q == "S" or Q == "send" or Q == "Send" or Q == "SEND":
		if S_THREADS == "n":
			for TO_ in XINO:
				if S_RETRYFAILED != "n":
					for TRYONCE__ in xrange(int(S_RETRYFAILED)):
						if SEND(TO_) == True:
							if S_DELAY != "n":
								time.sleep(int(S_DELAY))
							break
						else:
							pass
				else:
					SEND(TO_)
					if S_DELAY != "n":
						time.sleep(int(S_DELAY))
		else:
			if __name__ == '__main__':
				pool = ThreadPool(int(S_THREADS))
				for _ in pool.imap_unordered(SEND, XINO):
					pass
	elif Q == "r" or Q == "R" or Q == "mailer" or Q == "Mailer" or Q == "MAILER":
		if M_THREADS == "n":
			for TO_ in XINO:
				Mailers(TO_)
		else:
			if __name__ == '__main__':
				pool = ThreadPool(int(M_THREADS))
				for _ in pool.imap_unordered(Mailers, XINO):
					pass
	elif Q == "g" or Q == "G" or Q == "gmass" or Q == "Gmass" or Q == "GMASS":
		print "%s%s \n\t-| Auto = a \n%s" % (fg(52), bg(0), attr(0)) + "%s%s \t-| None = n \n%s" % (fg(52), bg(0), attr(0)) + "%s%s \t-| SslOnConnect = s \n%s" % (fg(52), bg(0), attr(0)) + "%s%s \t-| StartTls = t \n%s" % (fg(52), bg(0), attr(0)) + "%s%s \t-| StartTlsWhenAvailable = tv\n%s" % (fg(52), bg(0), attr(0))
		SEC__ = raw_input("%s%s\tSecurity #~/ %s" % (fg(22), bg(0), attr(0)))
		for SMTP_LINE in SMTPS__:
			GMASS_TEST(SMTP_LINE, SEC__)
	else:
		print "%s%s\t[ - ] Please Choose Correct Choice!!%s" % (fg(52), bg(0), attr(0))
	print "\n\n"
	_FUCK_ = raw_input("%s%s\tEnter To Start Again #~/ %s" % (fg(22), bg(0), attr(0)))